#pragma once
#include "Vector.hpp"

void shuffle(Vector<int>& numbers);
