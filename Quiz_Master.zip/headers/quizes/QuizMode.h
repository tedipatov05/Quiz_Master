#pragma once

enum class QuizMode {
	Test,
	Normal,
	Unknown
};
