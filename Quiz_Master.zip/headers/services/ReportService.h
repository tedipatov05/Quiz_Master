#pragma once
#include "../../headers/Context.h"

class ReportService{

public:

	static void printReports(const Context& ctx);
};

